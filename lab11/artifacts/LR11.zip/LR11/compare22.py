import lab11_lib as L

M = L.variant_summary(22)

print("Вариант:", M["variant"])
print("Контекст:", M["ctx"])
print("Фактор:", M["factor"])

print("\nМетрика | A | s | B | Delta | |Delta|/s | >2s")

for row in M["rows"]:
    print(row)

print("\nЭксперимент завершён")
