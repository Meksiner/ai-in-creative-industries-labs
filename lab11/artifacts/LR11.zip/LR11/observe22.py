from pathlib import Path
import csv
import numpy as np
import torch
from PIL import Image
import lab11_lib as L

OUT = Path('samples')
OUT.mkdir(exist_ok=True)
KIND, CFG_A, CFG_B = L.variant_settings(22)
SEED = 101
SNAPSHOTS = (100, 300, 700, 1500)


def save_grid(images, path, cols=8):
    images = images.detach().cpu().clamp(0, 1)
    n, c, h, w = images.shape
    rows = (n + cols - 1) // cols
    canvas = Image.new('RGB', (cols * w, rows * h))
    for i, tensor in enumerate(images):
        rgb = (tensor.permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
        canvas.paste(Image.fromarray(rgb), ((i % cols) * w, (i // cols) * h))
    canvas.resize((cols * w * 3, rows * h * 3), Image.Resampling.NEAREST).save(path)


def snapshot(step, generator):
    was_training = generator.training
    generator.eval()
    with torch.no_grad():
        images = L.sample(generator, n=32, seed=2022)
    generator.train(was_training)
    save_grid(images, OUT / f'A_seed101_step{step}.png')
    print(f'Saved step {step}', flush=True)


print('Variant 22, kind:', KIND, 'factor:', L.FACTORS[3], flush=True)
print('Device:', L.DEVICE, 'Torch:', torch.__version__, 'Threads:', torch.get_num_threads(), flush=True)
Xtr = L.L.dataset(KIND)[0][:CFG_A['n_train']]
G, hist = L.train_gan(Xtr, CFG_A, SEED, snapshots=SNAPSHOTS, on_snapshot=snapshot)

with (OUT / 'A_seed101_history.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['step', 'loss_d', 'loss_g', 'd_real', 'd_fake'])
    for i in range(len(hist['ld'])):
        writer.writerow([1 + 10 * i, hist['ld'][i], hist['lg'][i], hist['d_real'][i], hist['d_fake'][i]])

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    steps = [1 + 10 * i for i in range(len(hist['ld']))]
    fig, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    axes[0].plot(steps, hist['lg'], label='Generator loss')
    axes[0].plot(steps, hist['ld'], label='Discriminator loss')
    axes[0].legend()
    axes[0].set_ylabel('Loss')
    axes[1].plot(steps, hist['d_real'], label='D(real)')
    axes[1].plot(steps, hist['d_fake'], label='D(fake)')
    axes[1].legend()
    axes[1].set_xlabel('Training step')
    axes[1].set_ylabel('Mean D output')
    fig.tight_layout()
    fig.savefig(OUT / 'A_seed101_training.png', dpi=160)
    plt.close(fig)
    print('Saved training plot', flush=True)
except ImportError as e:
    print('Plot skipped: matplotlib unavailable:', e, flush=True)

print('Observed training complete.', flush=True)
