from pathlib import Path
import csv
import numpy as np
import torch
from PIL import Image, ImageOps, ImageDraw
import lab11_lib as L

OUT = Path('samples')
OUT.mkdir(exist_ok=True)
KIND, CFG_A, CFG_B = L.variant_settings(22)
SEED = 101
SNAPSHOTS = (100, 300, 700, 1500)

def save_grid(images, path, cols=8):
    images = images.detach().cpu().clamp(0, 1)
    n, c, h, w = images.shape
    rows = (n + cols - 1) // cols
    canvas = Image.new('RGB', (cols * w, rows * h))
    for i, tensor in enumerate(images):
        rgb = (tensor.permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
        canvas.paste(Image.fromarray(rgb), ((i % cols) * w, (i // cols) * h))
    canvas.resize((cols * w * 3, rows * h * 3), Image.Resampling.NEAREST).save(path)

def snapshot(step, generator):
    was_training = generator.training
    generator.eval()
    with torch.no_grad():
        images = L.sample(generator, n=32, seed=2022)
    generator.train(was_training)
    save_grid(images, OUT / f'B_seed101_step{step}.png')
    print(f'Saved B step {step}', flush=True)

print('Variant 22:', KIND, 'factor: beta1_0.5_to_0.9', flush=True)
print('Device:', L.DEVICE, 'Torch:', torch.__version__, 'Threads:', torch.get_num_threads(), flush=True)
Xtr = L.L.dataset(KIND)[0][:CFG_B['n_train']]
G, hist = L.train_gan(Xtr, CFG_B, SEED, snapshots=SNAPSHOTS, on_snapshot=snapshot)

with (OUT / 'B_seed101_history.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['step', 'loss_d', 'loss_g', 'd_real', 'd_fake'])
    for i in range(len(hist['ld'])):
        writer.writerow([1 + 10*i, hist['ld'][i], hist['lg'][i], hist['d_real'][i], hist['d_fake'][i]])

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    steps = [1 + 10*i for i in range(len(hist['ld']))]
    fig, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    axes[0].plot(steps, hist['lg'], label='Generator loss')
    axes[0].plot(steps, hist['ld'], label='Discriminator loss')
    axes[0].legend()
    axes[0].set_ylabel('Loss')
    axes[1].plot(steps, hist['d_real'], label='D(real)')
    axes[1].plot(steps, hist['d_fake'], label='D(fake)')
    axes[1].legend()
    axes[1].set_xlabel('Training step')
    axes[1].set_ylabel('Mean D output')
    fig.tight_layout()
    fig.savefig(OUT / 'B_seed101_training.png', dpi=160)
    plt.close(fig)
except ImportError:
    print('matplotlib unavailable; CSV saved', flush=True)

left_path = OUT / 'A_seed101_step1500.png'
right_path = OUT / 'B_seed101_step1500.png'
if left_path.exists() and right_path.exists():
    left = Image.open(left_path).convert('RGB')
    right = Image.open(right_path).convert('RGB')
    target = (max(left.width, right.width), max(left.height, right.height))
    left = left.resize(target)
    right = right.resize(target)
    margin, header = 18, 36
    canvas = Image.new('RGB', (target[0]*2 + margin*3, target[1] + header + margin*2), 'white')
    draw = ImageDraw.Draw(canvas)
    draw.text((margin, 12), 'A: beta1=0.5', fill='black')
    draw.text((target[0] + margin*2, 12), 'B: beta1=0.9', fill='black')
    canvas.paste(left, (margin, header))
    canvas.paste(right, (target[0] + margin*2, header))
    canvas.save(OUT / 'AB_seed101_step1500.png')
    print('Saved A/B comparison sheet', flush=True)
else:
    print('A sheet not found; upload or keep samples/A_seed101_step1500.png to build comparison', flush=True)
print('B observed training complete.', flush=True)