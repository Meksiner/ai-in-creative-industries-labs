import lab10_lib as L

# Вариант 22
M = L.variant_summary(22, save_dir="v22")

# Вывод результатов
print("Результаты варианта 22:")
for row in M["rows"]:
    print(row)

# Создание листов слепого сравнения
L.blind_sheets(22, "v22")

print("Эксперимент завершён")
