import numpy as np
import torch
from PIL import Image
import lab07_lib as L
import lab08_lib as V

kind = L.KINDS[3]
Xte = L.dataset(kind)[1]

def strip(imgs):
    return np.concatenate(
        list(imgs.permute(0, 2, 3, 1).cpu().numpy()),
        axis=1
    )

rows = []

with torch.no_grad():
    pass

for d in (8, 32):
    model = V.get_model(kind, dict(V.BASE, d=d), 101)
    model.eval()

    g = torch.Generator(device="cpu").manual_seed(5)
    z = torch.randn((8, d), generator=g).to(L.DEVICE)

    with torch.no_grad():
        rows.append(strip(model.decode(z)))

        za = model.encode(Xte[0:1])
        zb = model.encode(Xte[2:3])
        t = torch.linspace(0, 1, 8, device=L.DEVICE).unsqueeze(1)

        rows.append(strip(
            model.decode((1 - t) * za + t * zb)
        ))

sheet = Image.fromarray(
    (np.concatenate(rows, axis=0) * 255)
    .round().astype("uint8")
)

sheet = sheet.resize(
    (8 * 32 * 4, 4 * 32 * 4),
    Image.Resampling.NEAREST
)

sheet.save("comparison.png")
print("Создан comparison.png")
