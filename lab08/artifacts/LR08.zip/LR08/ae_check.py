import lab07_lib as L
import lab08_lib as V

kind = "disc_color"

for beta in (0.0, 1.0):
    cfg = dict(V.BASE, d=8, beta=beta)
    model = V.get_model(kind, cfg, 101)
    m = V.metrics(model, kind, "lin", 1.0, 101)

    print(f"beta={beta}")
    print(f"Сэмплы PSNR: {m['sample']:.3f} дБ")
    print(f"Реконструкция PSNR: {m['recon']:.3f} дБ")
    print(f"Интерполяция PSNR: {m['interp']:.3f} дБ")
