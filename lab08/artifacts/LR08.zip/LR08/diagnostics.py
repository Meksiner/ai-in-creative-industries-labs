import torch
import lab07_lib as L
import lab08_lib as V

kind = L.KINDS[3]
Xte = L.dataset(kind)[1]

for d in (8, 32):
    cfg = dict(V.BASE, d=d)
    model = V.get_model(kind, cfg, 101)

    with torch.no_grad():
        mu, lv = model.encode_dist(Xte)
        kl_axis = (-0.5 * (
            1 + lv - mu ** 2 - lv.exp()
        )).mean(0)

    active = int((kl_axis > 0.05).sum())

    print(f"\nРазмерность d={d}")
    print("Разброс mu:", mu.std(0).cpu().numpy().round(3))
    print("Активных осей:", active)