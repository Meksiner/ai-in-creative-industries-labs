run(pipeline(
    `$PY -u -c "import lab09_lib as L; p=L.load_pipe(); a=L.generate(p,L.prompt_a(3),101); a.save('variant22_A.png'); b=L.generate(p,L.prompt_b(3,3),101); b.save('variant22_B.png'); print('DONE',flush=True)"`,
    stdout="images22_out.txt",
    stderr="images22_err.txt"
))