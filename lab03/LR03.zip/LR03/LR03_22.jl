include("lab03_lib.jl")

println("Julia: ", VERSION)
println("Сцена: ", scene_preset(4))

img = make_scene(101; scene_preset(4)...)
println("Свойства изображения: ", describe_image(img))

# Два способа вычисления яркости
g_manual = luma_manual(img)
g_images = luma_images(img)

println("Максимальная разница яркости: ",
        maximum(abs.(g_manual .- g_images)))

# Проверка воспроизводимости
img_repeat = make_scene(101; scene_preset(4)...)
g_repeat = luma_images(img_repeat)

hash1 = array_sha(g_images)
hash2 = array_sha(g_repeat)

println("SHA-256 №1: ", hash1)
println("SHA-256 №2: ", hash2)
println("Совпадение: ", hash1 == hash2)

using Plots

# Применяем воздействие варианта 22
g_after = apply_factor(g_images, 4)

println("Яркость до: ", metrics3(g_images))
println("Яркость после: ", metrics3(g_after))
println("PSNR: ", psnr_db(g_images, g_after))

# Гистограммы с одинаковыми интервалами
bins = 32
counts_before = hist_counts(g_images, bins)
counts_after = hist_counts(g_after, bins)

centers = ((1:bins) .- 0.5) ./ bins

p1 = bar(centers, counts_before,
    title="До растяжения",
    xlabel="Яркость",
    ylabel="Количество пикселей",
    label=false,
    xlim=(0, 1))

p2 = bar(centers, counts_after,
    title="После растяжения",
    xlabel="Яркость",
    ylabel="Количество пикселей",
    label=false,
    xlim=(0, 1))

p = plot(p1, p2, layout=(1, 2), size=(1000, 400))

# Сохраняем результаты в папку LR03
outdir = "/user/zybin/LR03"

savefig(p, joinpath(outdir, "histograms_22.png"))
save(joinpath(outdir, "before_22.png"), Gray{N0f8}.(g_images))
save(joinpath(outdir, "after_22.png"), Gray{N0f8}.(g_after))

println("Гистограммы и изображения сохранены")

println("\n=== РЕЗУЛЬТАТЫ ВАРИАНТА 22 ===")

result = variant_summary(22)

println("Вариант: ", result.variant)
println("Сцена: ", result.ctx)
println("Воздействие: ", result.fac)
println("Средний PSNR: ", result.psnr, " дБ")

for row in result.rows
    println("\nМетрика: ", row[1])
    println("До: ", row[2])
    println("Разброс s: ", row[3])
    println("После: ", row[4])
    println("Изменение Δ: ", row[5])
    println("|Δ|/s: ", row[6])
    println("Статистически заметно: ", row[7])
end