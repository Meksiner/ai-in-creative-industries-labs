include("lab04_lib.jl")

println("Версия Julia: ", VERSION)
println("Параметры сцены: ", scene4(4))

img = make_gray4(101; scene4(4)...)
clean = clean4(4)

println("Размер изображения: ", size(img))
println("Размер эталона: ", size(clean))
println("PSNR до обработки: ", psnr_db(img, clean), " дБ")

println("\n--- Обработка изображения ---")

result, base, reference = pair4(img, clean, 4)

println("PSNR до: ", psnr_db(base, reference))
println("PSNR после: ", psnr_db(result, reference))

println("Энергия границ до: ", edge_energy(base))
println("Энергия границ после: ", edge_energy(result))

println("Контраст до: ", std(base))
println("Контраст после: ", std(result))

using Images

save("noisy_22.png", Gray.(img))
save("result_22.png", Gray.(result))
save("reference_22.png", Gray.(clean))

println("Три изображения сохранены")

println("\n--- Результаты варианта 22 ---")

summary = variant_summary4(22)

println("Вариант: ", summary.variant)
println("Сцена: ", summary.ctx)
println("Операция: ", summary.fac)

for row in summary.rows
    println("\nМетрика: ", row[1])
    println("До: ", row[2])
    println("Разброс s: ", row[3])
    println("После: ", row[4])
    println("Изменение Δ: ", row[5])
    println("|Δ|/s: ", row[6])
    println("Статистически заметно: ", row[7])
end

println("\n--- Намеренно введённая ошибка ---")

# Неправильно: сравнение с зашумлённым изображением
psnr_wrong = psnr_db(result, img)

# Правильно: сравнение с чистым эталоном
psnr_correct = psnr_db(result, clean)

println("Неправильный PSNR: ", psnr_wrong, " дБ")
println("Правильный PSNR: ", psnr_correct, " дБ")

println("Разница: ", psnr_wrong - psnr_correct, " дБ")